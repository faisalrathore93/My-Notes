var express = require('express');
var people = express.Router();
var mysql = require('mysql');

var connection = mysql.createConnection({
    //connection properties
        host:'127.0.0.1',
        user:'root',
        password:'',
        database:'nodeapp'
    });
    



//All the url will be appended with /api/people

//In real APP we need to get this from DB

var peoplesList =   [
    { id:0, name: "imran", password: "black",isAdmin:1 },
    { id:1, name: "faizan", password: "red",isAdmin:0 },
    { id:2, name: "mutazir", password: "green",isAdmin:0 },
    { id:3,  name: "dennis", password: "maroon",isAdmin:1 }
];




//Getting Admins
var isAdmin = [];

people.get('/admin', function (req, res) {
    
    peoplesList.forEach(function(person){
        var admin = {
            name:person.name,
            isAdmin:person.isAdmin
        }
        isAdmin.push(admin);
    });
            res.send(isAdmin);

});




//Getting All Peoples

people.get('/', function (req, res) {
    res
    .send(peoplesList);
});





//Getting People with Id
people.get('/:id', function (req, res) {
    res
    .send(peoplesList[req.params.id]);
});






//Adding new People
people.post('/',function(req,res){  
    if(!req.body.username){
        res.status(400).send('Name not provided');
        return;
    }  
    
 //   console.log("insert into users(ussername,password,isAdmin) values('"+req.body.username+"','"+req.body.password+"','"+req.body.isAdmin+"');")
        connection.query("insert into users(username,password,isAdmin) values('"+req.body.username+"','"+req.body.password+"','"+req.body.isAdmin+"');",function(error,rows,field)
        {
            if(!!error)
            {
                console.log("Error in Query");
             }
            else{
                res.send('<script>alert("Done");</script>');
            
            }
        })
    res.redirect('../login');

});




//Updating People Details
people.put('/:id',function(req,res){
    peoplesList[req.params.id].name=req.body.name;
    res.send(peoplesList);

});
module.exports = people;