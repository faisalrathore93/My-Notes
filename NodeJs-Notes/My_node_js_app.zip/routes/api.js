var express = require('express');
var api = express.Router();




api.get('/',function(req,res){
    res.send('Welcome to Flipkart Shopping API');
});


module.exports=api;