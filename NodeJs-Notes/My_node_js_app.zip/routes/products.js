var express = require('express');
var products  = express.Router();

var list = [

    {id:1, ProductName:'ToothPaste',price:10},
    {id:1, ProductName:'Brush',price:10},
    {id:1, ProductName:'Toolkit',price:10},
    {id:1, ProductName:'Hammer',price:10},
    {id:1, ProductName:'ToothPaste',price:10},
    {id:1, ProductName:'ToothPaste',price:10},
    {id:1, ProductName:'ToothPaste',price:10},
    {id:1, ProductName:'ToothPaste',price:10},
    {id:1, ProductName:'ToothPaste',price:10},


]

products.get('/',function(req,res){


});


products.get('/:id',function(req,res){

    
});



products.PUT('/',function(req,res){

    
});