var express = require('express');
var auth = express.Router();
var mysql = require('mysql');



var connection = mysql.createConnection({
    //connection properties
        host:'127.0.0.1',
        user:'root',
        password:'',
        database:'nodeapp'
    });
    



//============================================== Handles Rending of register Page =====================================
auth.get('/register',function(req,res){

    res.render('register');
});





//============================================== Handles Registering of users =====================================

auth.post('/register',function(req,res){  
    if(!req.body.username){
        res.status(400).send('Name not provided');
        return;
    }  
    
 //   console.log("insert into users(ussername,password,isAdmin) values('"+req.body.username+"','"+req.body.password+"','"+req.body.isAdmin+"');")
        connection.query("insert into users(username,password,isAdmin) values('"+req.body.username+"','"+req.body.password+"','"+req.body.isAdmin+"');",function(error,rows,field)
        {
            if(!!error)
            {
                console.log("Error in Query");
             }
            else{
                res.send('<script>alert("Done");</script>');
            
            }
        })
    res.redirect('../auth/login');

});


//============================================== Handles Login page Rendering =====================================

auth.get('/login',function(req,res){

    res.render('login');
});


//============================================== Handles Login  =====================================


auth.post('/login',function(req,res){

    var Cusername =req.body.username;
    var Cpassword = req.body.password;
    connection.query("SELECT * FROM users WHERE username='"+Cusername+"';",function(error,rows,field){

        if(Cpassword==rows[0].password)
        {
            res.send('You are Logged in');
         }
         else
         {
             res.send("Login Failed")
         }
    })
});

module.exports=auth;